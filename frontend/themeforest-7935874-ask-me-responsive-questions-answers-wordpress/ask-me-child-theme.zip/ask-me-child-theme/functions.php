<?php
add_action('wp_enqueue_scripts','vpanel_enqueue_parent_theme_style',20);
function vpanel_enqueue_parent_theme_style() {
	wp_enqueue_style('v_css',get_template_directory_uri().'/style.css');
	wp_enqueue_style('v_child_theme',get_stylesheet_uri(),'',null,'all');
}