package rajasthan.hackathon.healthmitra;

/**
 * Created by Sanskar on 3/21/2017.
 */
public class users {


    public String email,password,aadhar,userid,mobile,key;

    public users() {
        // Default constructor required for calls to DataSnapshot.getValue(User.class)
    }

    public users(String email, String password, String aadhar,String userid,String mobile,String key) {
        this.email = email;
        this.password = password;
        this.aadhar=aadhar;
        this.userid=userid;
        this.mobile=mobile;
        this.key=key;
    }


}
